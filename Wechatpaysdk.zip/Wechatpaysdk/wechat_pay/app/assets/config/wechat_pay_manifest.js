//= link_directory ../javascripts/wechat_pay .js
//= link_directory ../stylesheets/wechat_pay .css
