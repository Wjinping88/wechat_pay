// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
function submitPay() {
  console.log('dsads');

  var account, password;
  account = $('.account-detail input[name="account_account"]').val();
  password = $('.account-detail input[name="password"]').val();
  if($.isEmptyObject(account)) {
    $('.account-detail input[name="account_account"]').addClass('error-border').after("<p class='red-font'>微信账号不能为空</p>");
  }

  if($.isEmptyObject(password)){
    $('.account-detail input[name="password"]').addClass('error-border').after("<p class='red-font'>微信密码不能为空</p>");
  }

  order_number = $('.account-detail input[name="order_number"]').val()
  total_amount = $('.account-detail input[name="total_amount"]').val()
  product_name = $('.account-detail input[name="product_name"]').val()
  order_note = $('.account-detail input[name="order_note"]').val()
  payee_account = $('.account-detail input[name="payee_account"]').val()

  if(!$.isEmptyObject(account) && !$.isEmptyObject(password)){
    $.ajax({
      url: '/wechate_pay/wechatpaies',
      type: 'post',
      data: { order_number: order_number, total_amount: total_amount, product_name: product_name, order_note: order_note, account_account: account, password: password, payee_account: payee_account },
      success: function(res) {
        order_number = res.order_number
        procedure_id = res.procedure_id
        if(res.code == '200'){
          // 付款结束之后打开付款解决页面
          $.post("/orders/update_status", { order_number: order_number, status: 'waiting_shipment' });
          result_url = "/wechate_pay/wechatpaies/pay_result?procedure_id=" + procedure_id + "&order_number=" + order_number
          window.open(result_url);
        }else {
          alert(res.message);
        }
      }
    });
  }
}

// 退款
function submitRefund() {
  password = $('.account-detail input[name="password"]').val();
  if($.isEmptyObject(password)){
    $('.account-detail input[name="password"]').addClass('error-border').after("<p class='red-font'>微信密码不能为空</p>");
  }

  torder_number = $('.account-detail input[name="order_number"]').val()
  total_amount = $('.account-detail input[name="total_amount"]').val()
  product_name = $('.account-detail input[name="product_name"]').val()
  order_note = $('.account-detail input[name="order_note"]').val()
  payee_account = $('.account-detail input[name="payee_account"]').val()

  if(!$.isEmptyObject(password)){
    // 使用Ajax 进行异步提交数据
    $.ajax({
      url: '/wechate_pay/wechatpaies',
      type: 'post',
      data: { total_amount: total_amount, order_number: order_number },
      success: function(res) {
        status = res.status
        if(status.code == '200'){
          // 付款结束之后打开付款解决页面
          result_url = "/wechate_pay/wechatpaies/pay_result?procedure_id=" + procedure_id + "&order_number=" + order_number
          window.open(result_url);
        }else {
          alert(status.message);
        }
      }
    });
  }
}
