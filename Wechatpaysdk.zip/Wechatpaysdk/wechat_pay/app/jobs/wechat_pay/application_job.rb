module WechatPay
  class ApplicationJob < ActiveJob::Base
  end
end
