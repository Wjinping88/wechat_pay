require_dependency "wechat_pay/application_controller"

module WechatPay
  class WechatpaiesController < ApplicationController

    def index
    end

    def new
      @order_number = params[:order_number]
      @total_amount = params[:total_amount]
      @order_note = params[:order_note]
      @product_name = params[:product_name]
      # @account = Account.where(id: params[:payee_id]).last
      @payee_account = params[:payee_account]

      # js order_number: @order_number, total_amount: @total_amount, order_note: @order_note, account: @account
    end

    # 开始创建支付记录
    def create
      # 验证账号密码是否正确
      unless Account.account_exist?(params[:account_account])
        render json: { code: 5000, message: '账号不存在' }
        return false
      end

      account = Account.where("phone=? OR email=?", params[:account_account], params[:account_account]).last
      # 验证密码是否正确
      unless account.validate_password?(params[:password])
        render json: { code: 5000, message: '密码错误' }
        return false
      end

      consume_procedure = Procedure.submit(params)
      render json: { code: 200, message: '账号余额不足', order_number: consume_procedure.try(:customer_number), procedure_id: consume_procedure.try(:id) }
    end

    # 退款申请
    def refund_apply
    end

    # 付款成功页面
    def pay_result
      @procedure = Procedure.where(id: params[:procedure_id]).last
    end

  end
end
