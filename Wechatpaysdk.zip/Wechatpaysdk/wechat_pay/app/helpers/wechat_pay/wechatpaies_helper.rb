module WechatPay
  module WechatpaiesHelper
  end
end
