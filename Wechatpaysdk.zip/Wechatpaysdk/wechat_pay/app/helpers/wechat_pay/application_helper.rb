module WechatPay
  module ApplicationHelper
  end
end
