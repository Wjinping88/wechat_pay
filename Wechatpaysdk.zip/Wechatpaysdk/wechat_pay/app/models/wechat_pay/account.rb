module WechatPay
  class Account < ApplicationRecord
    has_many :procedures

    module OperateType
      ICOME = 'income'

      CONSUME = 'consume'
    end

    def self.init
      options_attr = [{
          email: 'nanyangewdcs@sina.com',
          password: '111111',
          phone: '18321889635',
          total_amount: 3000
        },
      {
          email: 'yanping@sina.com',
          password: '111111',
          phone: '18321839345',
          total_amount: 3000
        },
      {
          email: 'jinping@sina.com',
          password: '111111',
          phone: '13021839783',
          total_amount: 3000
        }]

        Account.create(options_attr)
    end

    # 验证账号是否存在
    # @params phone_email [String] 手机号或者密码
    # @return bool true 账号存在
    def self.account_exist?(phone_email)
      Account.where("phone=? OR email=?", phone_email, phone_email).present?
    end

    # 验证账号余额是否足够支付
    # @params amount [Float] 金额
    # @return bool true 账号余额足够
    def validate_amount?(amount)
      self.total_amount >= amount
    end

    # 验证密码是否正确;密码是MD5加密
    # @params passwor [String] 验证用户密码
    # @return Bool true 密码正确； false 密码错误
    def validate_password?(password)
      self.password == password
    end

    # 修改订单金额
    # @params amount [Float] 金额
    # @operate_typr [string] 操作类型(income: 收入； consume: 消费)
    def update_amount(amount, operate_type)
      total_amount = self.total_amount.to_f
      if operate_type = Account::OperateType::ICOME
        total_amount = total_amount + amount
      elsif operate_type = Account::OperateType::CONSUME
        total_amount = total_amount - amount
      end

      self.update(total_amount: total_amount)
    end
  end
end
