module WechatPay
  class Procedure < ApplicationRecord
    belongs_to :account

    module Status
      # 成功
      SUCCESS = 'success'

      # 失败
      FAIL = 'fail'
    end

    module Operation
      # 收入
      ICOME = 'income'
      # 消费
      CONSUME = 'consume'
      # 退款
      REFUND = 'refund'
    end

    class << self
      # 类方法，提交进行付款操作
      # @example
      #   Procedure.submit({ payee_id: 1, account_accont: 'jinping@sina.com', total_amount: 40,
      #                      order_number: '20180415862184', callback_url: '', fail_url: '' })
      #
      # @params payee_id [Int] 收款方ID
      # @params total_amount [Float] 应付款金额
      # @params order_number [String] 订单编号
      # @params callback_url [string] 成功回调地址
      # @params fail_url [String] 失败回调地址
      # @return [String] 返回回调链接
      def submit(options)
        # 查询到收款
        payee = Account.where("phone=? OR email=?", options[:payee_account], options[:payee_account]).last
        # 查询付款方
        payor = Account.where("phone=? OR email=?", options[:account_account], options[:account_account]).last

        # 开始创建账号的付款记录和收款记录
        # 创建记录需要
        # 使用 begin end 进行异常捕捉
        # 使用 transaction 事务
        consume_procedure = { }
        begin
          self.transaction do
            operate_number = get_payment_no(20)
            # 创建消费流水
            consume_procedure = create_procedure(payor, options.merge(operation: Procedure::Operation::CONSUME, total_amount: options[:total_amount].to_f,
                                                                      pay_amount: options[:total_amount].to_f, opposite_account_id: payee.id,
                                                                      operate_number: operate_number))
            # 付款账号开始减金额
            payor.update_amount(options[:total_amount].to_f, Account::OperateType::CONSUME)

            # 创建收款记录
            income_procedure = create_procedure(payee, options.merge(operation: Procedure::Operation::ICOME, total_amount: options[:total_amount].to_f,
                                                                     pay_amount: options[:total_amount].to_f, opposite_account_id: payor.id,
                                                                     operate_number: operate_number))

            payee.update_amount(options[:total_amount].to_f, Account::OperateType::ICOME)
          end
        rescue => err
          Rails.logger.info "支付失败=>#{err.class}-#{err.message}"
        end

        consume_procedure
      end

      # 进行退款操作
      # @params options [Hash]
      # @params total_amount [Float] 退款金额
      # @options operate_number 支付时创建的流水号
      def refund_amount(options)
        # 查询接受款项用户
        payee = Account.where("phone=? OR email=?", options[:payee_account], options[:payee_account]).last
        # 查找需要退款用户
        payor = Account.where("phone=? OR email=?", options[:account_accont], options[:account_accont]).last

        begin
          self.transaction do
            # 查询支付记录
            procedure = Procedure.where(operate_number: options[:operate_number], opposite_account_id: payee.id).last

            # 修改付款记录为退款状态
            procedure.update(operation: Procedure::Operation::REFUND)

            # 创建退款记录
            income_procedure = create_procedure(payee, options.merge(operation: Procedure::Operation::REFUND,
                                                                     pay_amount: options[:total_amount], opposite_account_id: payor.id,
                                                                     operate_number: operate_number))
          end
        rescue => err
          Rails.logger.info "支付失败=>#{err.class}-#{err.message}"
        end
      end

      # 创建操作记录
      # @example
      #   Procedure.create_procedure(accout, { payee_id: 1, account_accont: 'jinping@sina.com', total_amount: 40,
      #                      order_number: '20180415862184' })
      # @params account [ApplicationRecord] 账号实力
      # @params options [Hash]
      # @return procedure [ApplicationRecord] 返回创建的激励
      def create_procedure(account, options)
        procedure = account.procedures.new()
        procedure.opposite_account_id = options[:opposite_account_id]
        procedure.operate_number = options[:operate_number] # 生成20位的操作流水
        procedure.customer_number = options[:order_number] # 客户传过来的编码
        procedure.total_amount = options[:total_amount].to_f # 用户订单消费金额
        procedure.pay_amount = options[:pay_amount].to_f # 用户应该付款金额
        procedure.operation = options[:operation] # 操作是消费还是退款
        procedure.success_url = options[:success_url] if options[:success_url].present?
        procedure.fail_url = options[:fail_url] if options[:fail_url].present?
        procedure.save!

        procedure
      end

      # 生成流水号公共方法
      def get_payment_no(len)
        time_str = DateTime.now.strftime('%Y%m%d%H%M%S')
        prefix = time_str[0, 7]

        payment_no = "#{prefix}#{get_rand_number(len - prefix.length)}"

        return payment_no
      end

      def get_rand_number(len)
        code = ''
        chars = ("0".."9").to_a

        1.upto(len) { |i| code << chars[rand(chars.size-1)] }

        code
      end
    end

  end
end
