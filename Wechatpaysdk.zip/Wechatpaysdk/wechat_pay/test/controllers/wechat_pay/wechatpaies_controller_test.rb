require 'test_helper'

module WechatPay
  class WechatpaiesControllerTest < ActionDispatch::IntegrationTest
    include Engine.routes.url_helpers

    # test "the truth" do
    #   assert true
    # end
  end
end
