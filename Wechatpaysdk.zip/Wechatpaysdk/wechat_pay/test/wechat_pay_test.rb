require 'test_helper'

class WechatPay::Test < ActiveSupport::TestCase
  test "truth" do
    assert_kind_of Module, WechatPay
  end
end
