require 'test_helper'

module WechatPay
  class AccountTest < ActiveSupport::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end
