require 'test_helper'

module WechatPay
  class ProcedureTest < ActiveSupport::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end
