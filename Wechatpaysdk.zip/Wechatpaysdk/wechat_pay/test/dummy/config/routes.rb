Rails.application.routes.draw do
  mount WechatPay::Engine => "/wechat_pay"
end
