WechatPay::Engine.routes.draw do
  resources :wechatpaies do
    collection do
      get :pay_result
      get :refund_apply
    end
  end
end
