class CreateWechatPayAccounts < ActiveRecord::Migration[5.1]
  def change
    create_table :wechat_pay_accounts, comment: '账号' do |t|
      t.string :email, null: false, default: "", comment: '邮箱'
      t.string :phone, comment: '手机号'
      t.string :password, comment: '密码'
      t.decimal :total_amount, precision: 10, scale: 2, default: 0.0, null: false, comment: "账号总金额"

      t.timestamps
    end
  end
end
