module WechatPay
  class Engine < ::Rails::Engine
    isolate_namespace WechatPay
  end
end
