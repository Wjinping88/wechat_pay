# This migration comes from wechat_pay (originally 20180501082813)
class AddCloumnToProcedures < ActiveRecord::Migration[5.1]
  def change
    add_column :wechat_pay_procedures, :opposite_account_id, :integer, index: true, comment: '对方账号'
  end
end
