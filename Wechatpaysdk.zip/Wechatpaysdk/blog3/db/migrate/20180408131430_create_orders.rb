class CreateOrders < ActiveRecord::Migration[5.1]
  def change
    create_table :orders, comment: '订单' do |t|
      t.belongs_to :user, index: true, comment: '用户'
      t.string :order_number, comment: '订单编号'
      t.decimal :total_amount, precision: 10, scale: 2, default: 0.0, null: false, comment: "总金额"
      t.decimal :payment_amount, precision: 10, scale: 2, default: 0.0, null: false, comment: "支付金额"
      t.decimal :total_weight, precision: 10, scale: 2, default: 0.0, null: false, comment: "总重量"
      t.datetime :payment_at, comment: '付款时间'
      t.string :note, comment: '备注'
      t.string :status, comment: '状态'

      t.timestamps null: false
    end

    create_table :order_items, comment: '订单子项' do |t|
      t.belongs_to :order, index: true, comment: '订单'
      t.string :product_name, comment: '商品名字'
      t.integer :quantity, default: 0, null: false, comment: '数量'
      t.decimal :price, precision: 10, scale: 2, default: 0.0, null: false, comment: "单价"
      t.decimal :weight, precision: 10, scale: 2, default: 0.0, null: false, comment: "重量"

      t.timestamps null: false
    end
  end
end
