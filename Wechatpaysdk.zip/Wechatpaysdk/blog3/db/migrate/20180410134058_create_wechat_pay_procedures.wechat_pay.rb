# This migration comes from wechat_pay (originally 20180410130939)
class CreateWechatPayProcedures < ActiveRecord::Migration[5.1]
  def change
    create_table :wechat_pay_procedures, commnet: '操作流程' do |t|
      t.belongs_to :account, index: true, comment: '账号'
      t.string :operate_number, comment: '操作流水'
      t.string :customer_number, comment: '客户编码'
      t.decimal :total_amount, precision: 10, scale: 2, default: 0.0, null: false, comment: "消费金额"
      t.decimal :pay_amount, precision: 10, scale: 2, default: 0.0, null: false, comment: '付款金额'
      t.string :status, commnet: '状态'
      t.string :operation, comment: '操作'
      t.string :success_url, comment: '成功返回地址'
      t.string :fail_url, comment: '失败返回地址'

      t.timestamps
    end
  end
end
