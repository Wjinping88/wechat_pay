# frozen_string_literal: true

class DeviseCreateUsers < ActiveRecord::Migration[5.1]
  def change
    create_table :users, comment: "用户" do |t|
      ## Database authenticatable
      t.string :email,              null: false, default: "", comment: '邮箱'
      t.string :encrypted_password, null: false, default: "", comment: '密码'
      t.string :name,               comment: '姓名'
      t.string :gender,             comment: '性别'
      t.string :phone,              comment: '手机'
      t.string :avatar,             comment: '头像'

      ## Recoverable
      t.string   :reset_password_token
      t.datetime :reset_password_sent_at

      ## Rememberable
      t.datetime :remember_created_at

      ## Trackable
      t.integer  :sign_in_count, default: 0, null: false, comment: '登录次数'
      t.datetime :current_sign_in_at, comment: '当前登录时间'
      t.datetime :last_sign_in_at, comment: '最后一次登录时间'
      t.inet     :current_sign_in_ip, commnet: '当前登录IP'
      t.inet     :last_sign_in_ip, comment: '最后一次登录IP'

      ## Confirmable
      # t.string   :confirmation_token
      # t.datetime :confirmed_at
      # t.datetime :confirmation_sent_at
      # t.string   :unconfirmed_email # Only if using reconfirmable

      ## Lockable
      # t.integer  :failed_attempts, default: 0, null: false # Only if lock strategy is :failed_attempts
      # t.string   :unlock_token # Only if unlock strategy is :email or :both
      # t.datetime :locked_at


      t.timestamps null: false
    end

    add_index :users, :email,                unique: true
    add_index :users, :reset_password_token, unique: true
    # add_index :users, :confirmation_token,   unique: true
    # add_index :users, :unlock_token,         unique: true
  end
end
