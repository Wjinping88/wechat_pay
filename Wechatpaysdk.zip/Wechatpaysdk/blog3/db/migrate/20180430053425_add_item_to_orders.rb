class AddItemToOrders < ActiveRecord::Migration[5.1]
  def change
    add_column :orders, :product_name, :string, comment: '商品名称'
    add_column :orders, :quantity, :integer, default: 0, null: false, comment: '数量'
    add_column :orders, :price, :decimal, precision: 10, scale: 2, default: 0.0, null: false, comment: "单价"
    add_column :orders, :weight, :decimal, precision: 10, scale: 2, default: 0.0, null: false, comment: "单个重量"
  end
end
