Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root 'main#root'
  devise_for :users, controllers: { sessions: 'users/sessions', registrations: 'users/registrations' }

  mount WechatPay::Engine, at: '/wechate_pay'

  resources :orders do
    collection do
      post :update_status # 修改订单状态
    end
  end
end
