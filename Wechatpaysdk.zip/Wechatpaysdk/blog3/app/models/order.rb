# == Schema Information
#
# Table name: orders
#
#  id             :integer          not null, primary key
#  user_id        :integer
#  order_number   :string
#  total_amount   :decimal(10, 2)   default("0.0"), not null
#  payment_amount :decimal(10, 2)   default("0.0"), not null
#  total_weight   :decimal(10, 2)   default("0.0"), not null
#  payment_at     :datetime
#  note           :string
#  status         :string
#  created_at     :datetime         not null
#  updated_at     :datetime         not null
#  product_name   :string
#  quantity       :integer          default("0"), not null
#  price          :decimal(10, 2)   default("0.0"), not null
#  weight         :decimal(10, 2)   default("0.0"), not null
#

class Order < ActiveRecord::Base
  extend Enumerize
  belongs_to :user

  has_many :order_items

  enumerize :status, in: [ :waiting_payment, :waiting_shipment, :completed, :cancelled, :refunded ]
  enumerize :product_name, in: [ :make_steel, :poetry ]

  validates :product_name, presence: true
  validates :total_amount, presence: true

end
