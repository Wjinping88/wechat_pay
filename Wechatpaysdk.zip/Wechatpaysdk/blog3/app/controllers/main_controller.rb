class MainController < ApplicationController
  skip_before_action only: [:root]

  def root
    @orders = Order.where(user_id: current_user.try(:id))
  end
end