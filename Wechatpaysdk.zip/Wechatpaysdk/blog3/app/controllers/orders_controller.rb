class OrdersController < ApplicationController
  def index
    @orders = Order.where(user_id: current_user.try(:id))
    @orders = @orders.where(order_number: params[:order_number]).order(created_at: :desc) if params[:order_number].present?
  end

  def show
    @order = Order.where(id: params[:id]).last
  end

  def new
    @order = Order.new(order_number: Time.now.to_i, quantity: 1)
  end

  def create
    @order = Order.new(order_params.merge(status: 'waiting_payment', user_id: current_user.id))
    @order.save

    redirect_to "/orders/#{@order.id}"
  end

  def destroy
    @order = Order.find(params[:id])
    @order.destroy

    redirect_to orders_path
  end

  # 修改订单状态
  def update_status
    order = Order.where(order_number: params[:order_number]).last
    order.update(status: params[:status])
  end

protected

  def order_params
    params.require(:order).permit(:order_number, :total_amount, :total_weight, :note, :quantity, :price, :product_name)
  end

end